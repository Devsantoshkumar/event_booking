<?php

session_start();

include("../private/core/autoload.php");

$app = new App();


?>