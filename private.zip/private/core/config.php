<?php

define('ROOT','http://localhost/EventBooking/public');
define('ASSETS','http://localhost/EventBooking/public/assets');


define("DBNAME","event_book_db");
define("DBHOST","localhost");
define("DBUSER","root");
define("DBPASSWORD","");
define("DBDRIVER","mysql");


?>