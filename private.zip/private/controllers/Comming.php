<?php

class Comming extends Controller{
    function index(){
        

        $this->view('comming_soon');
    }
}

?>